# This is used to fetch the genes in a certain pathway
from bioservices import KEGG
import sys


def IsGenes(gene):
    tmp = k.find("genes", gene)
    return "gene" in tmp


def IsPathway(pathway):
    tmp = k.find("pathway", pathway)
    return "pathway" in tmp


def IsDisease(disease):
    tmp = k.find("disease", disease)
    return tmp ==u'\n'


def InfoQuery(query):
    querytmp = query.split()
    queryInfo = []
    for i in querytmp:
        if (IsDisease(i)):
            return i
        elif (IsPathway(i) or IsGenes(i)):
            queryInfo.append(i)
    return "+".join(queryInfo)

if __name__ == "__main__":
    k = KEGG()

    # with open("Example_test.txt") as f:
    #     data = f.readlines()
    # for query in data:
    #     print query
    #     Info = InfoQuery(query)
    #     print k.find("hsa",Info)
    # f.close()

    query = sys.argv[1]
    Info = InfoQuery(query)
    print (k.find("hsa", Info))
